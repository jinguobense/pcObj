<template>
	<div>平台收益</div>
</template>

<script>
</script>

<style>
</style>
